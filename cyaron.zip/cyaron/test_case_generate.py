import os
from cyaron import *

BasePath = "E:\\kaoshi\\cyaron\\" 

if not os.path.exists(BasePath + "data\\"): 
    os.makedirs(BasePath + "data\\")  

for i in range (0, 10): # 生成 1 - 20 数据
    test_data = IO(file_prefix = BasePath + "data\\", data_id = i + 1)
    n = randint(10, 20)  # 在指定范围生成 a
    test_data.input_writeln(n)  # 将 a, b 写入 in 输入文件
    for i in range (0, n):
        a = randint(1, 200)
        test_data.input_write(a)

    test_data.input_writeln()  # 换行

    n = randint(1, 10)  # 在指定范围生成 a
    test_data.input_writeln(n)  # 将 a, b 写入 in 输入文件
    for i in range (0, n):
        a = randint(1, 200)
        test_data.input_write(a)

    test_data.output_gen(BasePath + "std\\generatestd.exe")  # 执行可执行程序, 将结果写入 out 输出文件
